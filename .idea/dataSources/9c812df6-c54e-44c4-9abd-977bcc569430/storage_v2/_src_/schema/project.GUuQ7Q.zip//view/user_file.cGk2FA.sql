create definer = root@`%` view user_file as
select `project`.`user`.`real_name`          AS `real_name`,
       `project`.`file`.`file_name`          AS `file_name`,
       `project`.`file`.`file_original_name` AS `file_original_name`
from (`project`.`user` left join `project`.`file` on ((`project`.`file`.`upload_user_id` = `project`.`user`.`id`)));

-- comment on column user_file.real_name not supported: 真实姓名

-- comment on column user_file.file_name not supported: 文件名称

-- comment on column user_file.file_original_name not supported: 文件原始名称

